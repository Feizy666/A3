const express = require('express');
const bodyParser = require('body-parser');
const morgan = require('morgan');
// 解决跨域
const cors = require('cors');


// 引入数据库连接
const db = require('./crowdfunding_db');

const app = express();
const port = process.env.PORT || 80;
const router = express.Router();

// 解决跨域问题
app.use(cors());

app.use(bodyParser.json());
app.use(morgan('dev'));
// 给所有路由添加 /api前缀
app.use('/api', router);

router.get('/category', (req, res) => {

    db.query('SELECT * FROM category', (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        res.json(results);
    });
});

router.get('/fundraiser', (req, res) => {

    db.query('SELECT f.*, c.category_id as categoryId,c.name FROM fundraiser f INNER JOIN category c on f.category_id = c.category_id order by f.active DESC', (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        res.json(results);
    });
});

router.get('/fundraiser/one/:id', (req, res) => {
    db.query('SELECT f.*, c.category_id as categoryId, c.name FROM fundraiser f INNER JOIN category c on f.category_id = c.category_id where f.id = ?', [req.params.id], (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        let resultData = results[0];
        // 处理活跃度
        let active = resultData.active + 1;

        const query = 'UPDATE fundraiser SET active = ? WHERE id = ?'; // 注意表名的单数形式
        db.query(query, [active, req.params.id], (err, updateResults) => {
            if (err) {
                return res.status(400).json({error: err.message});
            }
            res.json(resultData); // 发送查询结果
        });
    });
});

// 新增募捐记录
router.post('/fundraiser', (req, res) => {
    // 从请求体中获取数据
    const {organizer, title, targetFunding, city, status, categoryId} = req.body;

    // 检查是否有必填字段缺失
    if (!organizer || !title || !targetFunding || !city || !categoryId || !status) {
        return res.status(400).json({error: 'Missing required fields'});
    }

    // 插入数据的 SQL 语句
    const query = `
        INSERT INTO fundraiser (organizer, title, target_funding, city,status, category_id)
        VALUES (?, ?, ?, ?, ?, ?)
    `;

    // 执行插入操作
    db.query(query, [organizer, title, targetFunding, city, status, categoryId], (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }

        // 返回插入的结果
        res.json({
            message: 'created success', // 返回新创建记录的 ID
            id: results.insertId,
        });
    });
});

// 修改募捐记录
router.put('/fundraiser/:id', (req, res) => {
    // 从请求体中获取数据
    const {organizer, title, targetFunding, city, status, categoryId} = req.body;

    // 检查是否有必填字段缺失
    if (!organizer || !title || !targetFunding || !city || !status || !categoryId) {
        return res.status(400).json({error: 'missing required fields'});
    }

    // 更新数据的 SQL 语句
    const query = `
        UPDATE fundraiser 
        SET organizer = ?, title = ?, target_funding = ?, city = ?, status =?,  category_id = ? 
        WHERE id = ?
    `;

    // 执行更新操作
    db.query(query, [organizer, title, targetFunding, city, status, categoryId, req.params.id], (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }

        if (results.affectedRows === 0) {
            return res.status(404).json({error: 'fundraiser not found'});
        }

        // 返回更新的结果
        res.json({message: 'updated successfully'});
    });
});

// 删除募捐记录
router.delete('/fundraiser/:id', (req, res) => {
    console.log('Received DELETE request for ID:', req.params.id); // 记录接收到的 ID
    // 从 URL 中获取 ID
    const {id} = req.params;

    // 检查是否有相关的 donation 记录
    const checkDonationQuery = 'SELECT COUNT(*) AS count FROM donation WHERE fundraiser_id = ?';

    db.query(checkDonationQuery, [id], (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }

        // 如果存在 donation 记录，则返回错误消息
        if (results[0].count > 0) {
            return res.status(400).json({error: 'Cannot delete fundraiser with existing donations.'});
        }

        // 删除数据的 SQL 语句
        const deleteQuery = 'DELETE FROM fundraiser WHERE id = ?';

        // 执行删除操作
        db.query(deleteQuery, [id], (err, results) => {
            if (err) {
                return res.status(500).json({error: err.message});
            }

            if (results.affectedRows === 0) {
                return res.status(404).json({error: 'Fundraiser not found'});
            }

            // 返回删除的结果
            res.json({message: 'Deleted successfully!'});
        });
    });
});


// 多条件查询筹款活动
router.get('/fundraiser/search', (req, res) => {
    const {organizer, categoryId, city} = req.query;

    // 基础查询语句
    let query = 'SELECT * FROM fundraiser f INNER JOIN category c on f.category_id = c.category_id  WHERE 1=1';
    const params = [];

    // 动态添加条件
    if (organizer) {
        query += ' AND f.organizer LIKE ?';
        params.push(`%${organizer}%`);
    }
    if (categoryId) {
        query += ' AND f.category_id LIKE ?';
        params.push(`%${categoryId}%`);
    }
    if (city) {
        query += ' AND f.city LIKE ?';
        params.push(`%${city}%`);
    }

    query += " ORDER BY f.active DESC"


    console.log(query)

    db.query(query, params, (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        res.json(results);
    });
});

// 查看募捐脉络
router.get('/donation/:id', (req, res) => {

    // 记录接收到的 ID
    console.log('Received DELETE request for ID:', req.params.id);
    const id = req.params.id
    // 检查是否有相关的 donation 记录
    const checkDonationQuery = 'SELECT donation_id,DATE_FORMAT(date,"%Y-%m-%d %H:%i:%s") as date,amount,giver,fundraiser_id FROM donation WHERE fundraiser_id = ? ORDER BY date DESC';

    db.query(checkDonationQuery, [id], (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }
        res.json(results)
    })

});

// 新增募捐脉络
router.post('/donation', (req, res) => {
    // 从请求体中获取数据
    const {amount, giver, fundraiser_id} = req.body;
    console.log("amount", amount)
    console.log("giver", giver)
    console.log("fundraiser_id", fundraiser_id)

    // 检查是否有必填字段缺失
    if (!amount || !giver || !fundraiser_id) {
        return res.status(400).json({error: 'Missing required fields'});
    }

    // 插入 donation 数据的 SQL 语句
    const insertDonationQuery = `
        INSERT INTO donation (amount, giver, fundraiser_id)
        VALUES (?, ?, ?)
    `;

    // 执行插入操作
    db.query(insertDonationQuery, [amount, giver, fundraiser_id], (err, results) => {
        if (err) {
            return res.status(500).json({error: err.message});
        }

        // 插入成功，继续更新 fundraiser 的 current_funding 字段
        const updateFundraiserQuery = `
            UPDATE fundraiser 
            SET current_funding = current_funding + ? ,active = active +1
            WHERE id = ?
        `;

        // 更新操作：将当前资金增加 donation 的金额
        db.query(updateFundraiserQuery, [amount, fundraiser_id], (err, updateResults) => {
            if (err) {
                return res.status(500).json({error: err.message});
            }

            // 更新成功，返回插入 donation 的结果
            res.status(201).json({
                message: 'Donation created and fundraiser updated successfully!', donation_id: results.insertId, // 返回新创建记录的 donation_id
            });
        });
    });
});


app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
